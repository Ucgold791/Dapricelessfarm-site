export default function Home() {
  return (
    <div className="min-h-screen bg-white text-gray-800">
      {/* Header */}
      <header className="bg-green-700 text-white p-6 shadow-md">
        <h1 className="text-3xl font-bold">Dapricelessfarm</h1>
        <p className="text-sm">Purely Local. Proudly Priceless.</p>
      </header>

      {/* Hero Section */}
      <section className="bg-yellow-100 p-10 text-center">
        <h2 className="text-4xl font-bold mb-4">Premium Locally-Grown Rice</h2>
        <p className="mb-6 text-lg">Grown in Umumbo, Ayamelum LGA, Anambra State, Nigeria</p>
        <button className="bg-green-700 text-white px-6 py-2 rounded-full shadow hover:bg-green-800">
          Shop Now
        </button>
      </section>

      {/* Navigation */}
      <nav className="flex justify-center space-x-6 bg-white p-4 shadow-md">
        <a href="#about" className="hover:text-green-700">About Us</a>
        <a href="#products" className="hover:text-green-700">Products & Services</a>
        <a href="#gallery" className="hover:text-green-700">Gallery</a>
        <a href="#contact" className="hover:text-green-700">Contact</a>
        <a href="#booking" className="hover:text-green-700">Book Now</a>
      </nav>

      {/* About Us */}
      <section id="about" className="p-10 bg-white text-center">
        <h2 className="text-3xl font-bold mb-4">About Us</h2>
        <p className="max-w-2xl mx-auto text-lg">
          Dapricelessfarm is a local rice farming business located in Umumbo, Ayamelum LGA, Anambra State. We are passionate about producing high-quality, locally-grown rice that supports our community and promotes sustainable agriculture.
        </p>
      </section>

      {/* Products & Services */}
      <section id="products" className="p-10 bg-yellow-50">
        <h2 className="text-3xl font-bold mb-6 text-center">Our Products & Services</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="p-4 bg-white rounded shadow text-center">
            <img src="https://via.placeholder.com/150" alt="Rice Package" className="mx-auto mb-4" />
            <h3 className="font-bold text-xl">Premium Rice (1kg - 50kg)</h3>
            <p>Available in various sizes. Freshly processed and packaged.</p>
          </div>
          <div className="p-4 bg-white rounded shadow text-center">
            <img src="https://via.placeholder.com/150" alt="Bulk Supply" className="mx-auto mb-4" />
            <h3 className="font-bold text-xl">Bulk Supply</h3>
            <p>For distributors, retailers, or institutions. Contact us for deals.</p>
          </div>
          <div className="p-4 bg-white rounded shadow text-center">
            <img src="https://via.placeholder.com/150" alt="Farm Tours" className="mx-auto mb-4" />
            <h3 className="font-bold text-xl">Farm Visits & Tours</h3>
            <p>Experience rice farming first-hand with guided tours.</p>
          </div>
        </div>
      </section>

      {/* Gallery */}
      <section id="gallery" className="p-10 bg-white">
        <h2 className="text-3xl font-bold mb-6 text-center">Gallery</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <img src="https://via.placeholder.com/200" alt="Farm 1" className="rounded shadow" />
          <img src="https://via.placeholder.com/200" alt="Harvest" className="rounded shadow" />
          <img src="https://via.placeholder.com/200" alt="Packaging" className="rounded shadow" />
          <img src="https://via.placeholder.com/200" alt="Market" className="rounded shadow" />
        </div>
      </section>

      {/* Contact */}
      <section id="contact" className="p-10 bg-yellow-50 text-center">
        <h2 className="text-3xl font-bold mb-4">Contact Us</h2>
        <p>Email: info@dapricelessfarm.com</p>
        <p>Phone/WhatsApp: +234 801 234 5678</p>
        <p>Location: Umumbo, Ayamelum LGA, Anambra State, Nigeria</p>
      </section>

      {/* Booking Form */}
      <section id="booking" className="p-10 bg-white">
        <h2 className="text-3xl font-bold mb-6 text-center">Book a Visit or Order</h2>
        <form className="max-w-xl mx-auto grid gap-4">
          <input type="text" placeholder="Full Name" className="border p-3 rounded" required />
          <input type="email" placeholder="Email Address" className="border p-3 rounded" required />
          <input type="tel" placeholder="Phone Number" className="border p-3 rounded" required />
          <select className="border p-3 rounded" required>
            <option value="">Select Request Type</option>
            <option value="visit">Farm Visit</option>
            <option value="order">Bulk Order</option>
          </select>
          <input type="date" className="border p-3 rounded" required />
          <textarea placeholder="Additional Notes" className="border p-3 rounded" rows="4"></textarea>
          <button type="submit" className="bg-green-700 text-white py-3 rounded hover:bg-green-800">
            Submit Booking
          </button>
        </form>
      </section>

      {/* Footer */}
      <footer className="bg-green-700 text-white text-center p-4 mt-10">
        <p>&copy; {new Date().getFullYear()} Dapricelessfarm. All rights reserved.</p>
      </footer>
    </div>
  );
}